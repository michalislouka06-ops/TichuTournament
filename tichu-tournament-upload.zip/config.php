<?php
// Admin password for the live site. Change it here any time (cPanel > File Manager > Edit).

const ADMIN_PASSWORD = '1234';
